//Procedimiento del segundo punto del miniproyecto #4

import java.util.HashMap;
import java.util.Scanner;

public class App {
    
    HashMap<HashMap<String, String>, Float> directorioTelefonico = new HashMap<HashMap<String, String>, Float>();
    Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        App app = new App();
        app.menuPrincipal();
    }

    void menuPrincipal() {
        int opc = 0;

        while (opc != 3) {
            System.out.println("Bienvenido al menú del directorio telefónico. Ingresa la opción que deseas usar:");
            System.out.println("1.- Agregar persona y número telefónico");
            System.out.println("2.- Buscar número por el primer nombre");
            System.out.println("3.- Salir");
            opc = scanner.nextInt();

            switch (opc) {
                case 1:
                    agregarPersona();
                    break;

                case 2:
                    buscarNumero();
                    break;

                case 3:
                    break;

                default:
                    System.out.println("Opción no válida.\n");
                    break;
            }
        }
    }

    void agregarPersona() {
        System.out.println("Ingrese el primer nombre:");
        String nombre1 = scanner.next();

        System.out.println("Ingrese el segundo nombre:");
        String nombre2 = scanner.next();

        System.out.println("Ingrese el número telefónico:");
        float numTelefono = scanner.nextFloat();

        HashMap<String, String> persona = new HashMap<>();
        persona.put("Nombre1", nombre1);
        persona.put("Nombre2", nombre2);

        directorioTelefonico.put(persona, numTelefono);
        System.out.println("Persona añadida al directorio telefonico.\n");
    }

    void buscarNumero() {
        System.out.println("Ingrese el primer nombre de la persona que desea buscar:");
        String nombreBuscar = scanner.next();

        for (HashMap<String, String> persona : directorioTelefonico.keySet()) {
            if (persona.get("Nombre1").equals(nombreBuscar)) {
                Float numTelefono = directorioTelefonico.get(persona);
                System.out.println("Número telefónico de " + nombreBuscar + ": " + numTelefono + "\n");
                return;
            }
        }

        System.out.println("No se encontró ninguna persona con el primer nombre " + nombreBuscar + " en el directorio.\n");
    }
}
